$(document).ready(function(){
    $('#nav').onePageNav({
        currentClass: 'active'
    });
});
$(window).on('scroll', function(){
    if($(this).scrollTop() > 20){
        $('.header-area').addClass('sticky');
    }
    else{
        $('.header-area').removeClass('sticky');
    }
});

(function($){

jQuery(document).ready(function(){

    jQuery(window).scroll(function(){

        var sumonIt = jQuery(window).scrollTop();

        if ( sumonIt > 100 ){
            jQuery('.scroll-top').fadeIn();
        }else{
            jQuery('.scroll-top').fadeOut();
        }
    })

    jQuery('.scroll-top').on('click', function(){

        jQuery('html, body').animate({'scrollTop' : 0}, 500);

    })

})

}(jQuery));